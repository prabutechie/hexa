import React from 'react'
import './Hero.css'
import managedService from '../assets/ManagedServices.jpg'
import digitalTransform from '../assets/Digital-Transformation.jpg' 
import sharePoint from '../assets/SharePoint-Services.jpg' 
import ArrowForwardIcon from '@mui/icons-material/ArrowForward'
import intrBg from '../assets/intr-bg.png'
import howIcon01 from '../assets/how-icn-01.png'
import howIcon02 from '../assets/how-icn-02.png'
import howIcon03 from '../assets/how-icn-03.png'
import howIcon04 from '../assets/how-icn-04.png'
import playBtn from '../assets/play-button-1.png'

const Hero = () =>{
    return(
        <div className='Hero'>
            <div className='homeIntro'>
                <div className='homeIntroCont'>
                    <div className='homeLeft'>
                        <div className='leftTitle'>We build the right technical <br />
                            <h4>Solutions for our customer</h4>
                        </div>
                    </div>
                    <div className='homeRight'>
                            <b>Hexatral</b> understands the modern enterprise and delivers best-of-breed technical 
                            solutions that increase efficiencies, drive costs out of systems and increase revenue.
                    </div>
                </div>
            </div>
            <div className='heroCard'>
            {cardTxt.map((textCard) =>(
                <div className='cardContainer'>
                    
                        <div className='card'>
                            <div className='cardImg'>
                                <img src={textCard.img} alt='' />
                            </div>
                            <div className='cardImgCont'>
                                <h3>{textCard.head}</h3>
                                <p>{textCard.para}</p>
                            </div>
                         </div>
                        
                    <div className='cirArrow'>
                        <div className='rightArrow'> <ArrowForwardIcon style={arrowStyle}/> </div>
                    </div>
                </div>
                ))}
            </div>
            <div className='heroImg'>
                <img src={intrBg} alt='' />
            </div>
            <div className='heroIconCont'>
                <h2><strong>How</strong> can we help?</h2>
                <div className='heroContContainer'>
                {HelpTxt.map((textHelp) =>(
                    <div className='heroIconList'>
                        
                            <div className='listImg'>
                            <img src={textHelp.img} alt='' />
                            <div className='listImgCont'>
                                I want to <br /> <p>{textHelp.head}</p>
                            </div>
                        </div>
                       
                    </div>
                     ))}
                </div>    
            </div>
            <div className='heroVideo'>
                <h2><span>What</span> we focus on?</h2>
                <div className='heroVideoCont'>
                    <div className='heroMainVideo'>
                        <img src={playBtn} alt='' width='100px' height='100px'/>
                    </div>
                    <div className='heroSubVideo'>
                        <div className='heroSubVideo1'><img src={playBtn} alt='' width='60px' height='60px'/></div>
                        <div className='heroSubVideo2'><img src={playBtn} alt='' width='60px' height='60px'/></div>  
                    </div>
                </div>
                <div className='moreVideos'>
                    <div className='moreVidBtn'>More Videos</div>
                </div>
            </div>
        </div>
    )
}

export default Hero

const arrowStyle = {
 color : 'white',
 width : '86px',
 height : '44px',
 fontWeight : '700'
}

const cardTxt =[
    {
        id: 1,
        img: managedService,
        head: 'Managed Services',
        para: 'Hexatral Managed Services will keep your infrastructure and applications up and running, minimize downtime, improve resource utilization and maximize employee productivity. Managed services cover on-premises, Azure, AWS, Google Cloud and hybrid environments.'
    },
    {
        id: 2,
        img: digitalTransform,
        head: 'Digital Transformation',
        para: 'Hexatral blends technology and industry expertise to create value from digitalization, in every stage of your transformation journey. Our Digital Transformation strategy integrates connectivity, collaboration, analytics, intelligence and security across the business chain'
    },
    {
        id: 3,
        img: sharePoint,
        head: 'SharePoint Services',
        para: 'Our deep expertise in SharePoint Technology, backed by the best resources in the industry allows us to deliver robust SharePoint services to our clients. Our SharePoint process, practices and development methodology are the differentiators that make us stand out from other.'
    }
]

const HelpTxt =[
    {
        id: 1,
        img: howIcon01,
        head: 'drive digital transformation'
    },
    {
        id: 2,
        img: howIcon02,
        head: 'build a mobile app'
    },
    {
        id: 3,
        img: howIcon03,
        head: 'automate legacy applications'
    },
    {
        id: 4,
        img: howIcon04,
        head: 'buy Azure & Office 365 Licenses'
    }
]