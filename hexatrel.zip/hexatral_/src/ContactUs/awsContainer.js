import React from 'react'
import './aws.css'

const AwsContainer=()=>{
    return(
        <div className='awsContainer'>
            <div className='hexacorpWhy'>
                <p>We aim to provide great digital transformation services to our customers across the globe. 
                    Here are the different ways you can contact HexaCorp for service inquiries, support or general questions about us.
                </p>
                <div className='managed-h2'>
                    <h2>Chennai, India</h2>
                </div>

                <span>4th Floor, 7th St, Lakshmi Nagar, Valasaravakkam, Chennai, TamilNadu - 600087, India</span>
            </div>
        </div>
    )
}

export default AwsContainer

