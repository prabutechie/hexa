import React from 'react'
import './aws.css'

const AwsBanner=()=>{    
    return(
        <div className='contactBanner'>
            <h1>Contact Us</h1>          
        </div>
    )
}

export default AwsBanner