import React from 'react'
import AwsFooter from '../aws/awsFooter'
import AwsBanner from './awsBanner'
import AwsContainer from './awsContainer'

const ContactUs = () => {
    return(
        <>
            <AwsBanner />
            <AwsContainer />
            <AwsFooter />
        </>
    )
}

export default ContactUs