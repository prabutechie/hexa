import React from 'react'
import './Slider.css'
import { Slide } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'
import microsoftPowerPlatform from '../assets/microsoftPowerPlatform.jpg';
import b5InfrastructureManagment from '../assets/b5InfrastructureManagment.jpg';
import b2AzurBots from '../assets/b2AzurBots.jpg';
import assitants from '../assets/assitants.jpg';

const Slider = () => {
    return(
        <div className='Slider'>    
            <Slide >
                {Slideimage.map((slideImg, index)=>(
                    <div key={index}>
                        <div className='slideImg' >
                            <img src= {slideImg.url} alt='' />
                            <div class="container">
                                <div class="row">
                                    <div className='hero-head'> {slideImg.caption} </div> <br />
                                    <h2>{slideImg.subHead}</h2>
                                    <button className='know-btn'>Know More</button>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </Slide>            
        </div>    
    )
}

export default Slider

const Slideimage = [
    {
        url: microsoftPowerPlatform,
        caption: 'Cloud Transformation',
        subHead: 'Transform yourself to  Digital Enterprise '
    },
    {
        url: b5InfrastructureManagment,
        caption: 'Predictive AI  Bots',
        subHead: 'Improved agility and mitigate disturbance'
    },
    {
        url: b2AzurBots,
        caption: 'IT Consulting',
        subHead: 'Delighted Customer with business growth'
    },
    {
        url: assitants,
        caption: 'Contact Center',
        subHead: 'Reinvent your cloud contact center'
    }
]
