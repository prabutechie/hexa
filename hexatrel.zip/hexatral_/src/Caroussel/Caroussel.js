import React, {useRef} from 'react'
import {Rerousel} from 'rerousel'
import './Caroussel.css'
import emergencyReadiness from '../assets/emergency-readiness.jpg'
import hrmsApplication from '../assets/hrmsApplication.jpg'
import botsCognitive from '../assets/bots-and-cognitive.jpg'
import 'react-slideshow-image/dist/styles.css'
import EagleLogo from '../assets/aigleLogo.jpg';
import Matrimony from '../assets/matrimonyLogo.png'
import GoldenGopuram from '../assets/goldenGopuram.png'
import vknMatrimony from '../assets/vknMatrimony.png' 

const Caroussel= () =>{
    const ref = useRef(null)
    const fadeProperties = {
        duration: 1000,
        canSwipe: true,
      };

    return(
        <div className='Caroussel'>
            <div className='carousselTitle'>
                <h2>Case Studies</h2>
                <h4>Find out how Hexatral has helped organizations achieve success with our services and solutions</h4>
            </div>
            <div className='carousselContainer'>
            {carousselText.map((carousalText, index)=>(
                <div className='carousselCard' key={index}>
                    
                        <div className='carousselCardImg'>
                            <img src= {carousalText.url} alt='' />
                        </div>
                        <div className='carousselCardImgCont'>
                            <h4>{carousalText.heading}</h4>
                            <p>{carousalText.para}</p>
                            <span>Read more</span>
                        </div>
                  
                </div>
                 ))}
            </div>
            <div className='moreVideos viewAll'>
                    <div className='moreVidBtn'>View All</div>
            </div>

            <div className='carousselSlide'>
                <Rerousel {...fadeProperties} itemRef= {ref}>
                   
                    <div className='eagleLogo' ref={ref}> <img src={EagleLogo} alt='' /> </div>
                    <div className='matrimonyLogo' ref={ref}> <img src={Matrimony} alt='' /> </div>
                    <div className='goldenLogo' ref={ref}> <img src={GoldenGopuram} alt='' /> </div>
                    <div className='vknMatriLogo' ref={ref}> <img src={vknMatrimony} alt='' /> </div>  
                </Rerousel>
            </div>
        </div>
    )

}

export default Caroussel

const carousselText = [
    {
        id: 1,
        url: emergencyReadiness,
        heading: 'Emergency Readiness Document Approval Process for a global non-profit',
        para: 'Document approval process solution using Microsoft Power Platform...',
        readMore: 'Read More'
    },
    {
        id: 2,
        url: botsCognitive,
        heading: 'HRMS Application Migration to Azure',
        para: 'Hexatral Migration Experts quickly migrated on-premise application to Azure environments...',
        readMore: 'Read More'
    },
    {
        id: 3,
        url: hrmsApplication,
        heading: 'Bots and Cognitive applications for a leading Utility Provider',
        para: 'Conversational Bot using Azure Bot service, that helped employees easily find compliance related information....',
        readMore: 'Read More'
    }
]