import React from 'react'
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
import Header from './Header/Header';
import Home from './Home/Home';
import Footer from './Footer/Footer'
import Aws from './aws/aws';
import AwsCloud from './awsCloud/awsCloud';
import ContactUs from './ContactUs/ContactUs';

function App() {
  return ( 
    <div className="App">
      <Router>
      <Header />
      
      <Switch>
      <Route path='/aws' component={Aws} />
        <Route path='/aws-cloud' component={AwsCloud} />
        <Route path='/' exact component={Home} />
        <Route path='/contact-us' exact component={ContactUs} />
      </Switch>    
      <Footer />
      </Router>    
    </div>
    
  );
}

export default App;
