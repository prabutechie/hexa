import React from 'react'
import './aws.css'
import book from '../assets/awsCloud/book.png';
import coach from '../assets/awsCloud/coach.png';
import design from '../assets/awsCloud/design.png';
import restore from '../assets/awsCloud/restore.png';
import shield from '../assets/awsCloud/shield.png';

const AwsHero=()=>{
    return(
        <div className='awsHero'>
            <div className='managedService'>
                <div className='ManagedServiceHeader'>
                    <h2>Our AWS infrastructure services</h2>
                </div>
                <div className='managedServiceList'>
                   {managedTxt.map((mgmnt, index)=>(
                    <div className='managedList' key={index}>
                        <div className='mgmntImg'>
                            <img src={mgmnt.url} alt='' />
                        </div>
                        <div className='mgmntCont'>
                            <h3>{mgmnt.head}</h3>
                            <p>{mgmnt.paragraph}</p>
                        </div>
                    </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default AwsHero

const managedTxt = [
    {
        id: 1,
        url: coach,
        head: 'Capacity assessment and planning',
        paragraph:'Ensure top performance by estimating demand ahead of time'
    },
    {
        id: 2,
        url: design,
        head: 'Design and setup',
        paragraph:'We tailor custom VM extensions and hybrid options that suit your needs with a comprehensive cloud stack'
    },
    {
        id: 3,
        url: book,
        head: 'Automating and scripting',
        paragraph:'Eliminate the manual dependencies by leveraging robust automation'
    },
    {
        id: 4,
        url: restore,
        head: 'Failover and resiliency design',
        paragraph:'Worry free recovery and restoration'
    },
    {
        id: 5,
        url: shield,
        head: 'Identity, security and access management',
        paragraph:'Safely control who, how, when and where'
    }
]