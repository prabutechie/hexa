import React from 'react'
import './aws.css'
import AwsBanner from './awsBanner'
import AwsCloudBanner from './awsCloudBanner'
import AwsContainer from './awsContainer'
import AwsFooter from '../aws/awsFooter'
import AwsHero from './awsHero'
import AwsMigration from './awsMigration'

function AwsCloud(){
    return(
        <>
            <AwsBanner />
            <AwsCloudBanner />
            <AwsMigration />
            <AwsHero />
            <AwsContainer />
            <AwsFooter />     
        </>
    )
}

export default AwsCloud