import React from 'react'
import './awsCloud.css'

const AwsMigration= () =>{
    return(
        <div className='awsMigration'>
            
            {MigrationTxt.map((migrate) => (
                <div className='migrationCont'>
                    <h1>{migrate.title}</h1>
                    <h2>{migrate.head}</h2>
                    <p>{migrate.para}</p> 
                    <p>{migrate.para1}</p>
               </div>
            ))}
        </div>
    )
}

export default AwsMigration

const MigrationTxt =[
    {
        id: 1,
        head: 'Expert led assessment and planning',
        para:'Take control of your business network’s solutions and services conveniently and effectively',
        title:'Our AWS migration services'
    },
    {
        id: 2,
        head: 'Modernize legacies',
        para:'We will execute the migration of your legacy applications'
    },
    {
        id: 3,
        head: 'Migrate to an IaaS',
        para:'Get the best infrastructure as a service and smartly virtualize your hardware'
    },
    {
        id: 4,
        head: 'Database migration',
        para:'Confidently move to AWS RDS or DynamoDB',
        para1:'What about some intelligent business analytics that bring your data to life with rich visuals? We will help you to embed stunning, interactive reports and dashboards within your business analytics applications. Additionally, enable self-service and vital data discovery for your business users. HexaCorp’s analytics experts will assist in combining data from disparate sources yielding crucial insights.'
    }
]