import React from 'react'
import './aws.css'

const AwsBanner=()=>{
    return(
        <div className='CloudBanner'>
            <h1>AWS Cloud Services</h1>
        </div>
    )
}

export default AwsBanner