import React from 'react'
import './awsCloud.css'
import AwsCloudServices from '../assets/awsCloud/AWS-Cloud-Services.jpg'
import tick from '../assets/awsCloud/tick.png'

const AwsCloudBanner = () => {
    return(
        <div className='AwsCloudBanner'>
            <p>HexaCorp’s AWS-certified cloud consultants help your business take full advantage of the cloud. Our skilled AWS experts carefully assess your existing infrastructure and recommend the most optimal solution customized for your business. 
                Be worry free and let us help your business with a digital transformation.
            </p>
            <div className='CloudBannerContainer'>
                <div className='CloudBannerList'>
                    <h2>HexaCorp’s AWS Cloud Services:</h2>
                    <ul className='cloudPoints'>
                       {cloudTxt.map((cloudText)=>(
                           <li><img src={tick} alt='' /> {cloudText.cont}</li>
                       ))} 
                    </ul>
                </div>
                <div className='CloudBannerImgCont'>
                    <div className='bannerImg'>
                        <img src={AwsCloudServices} alt='aws-banner' />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AwsCloudBanner

const cloudTxt = [
    {
        id:1,
        cont: 'Certified experts to advise your business across the full spectrum of AWS offerings'
    },
    {
        id:2,
        cont: 'Infrastructure and application migration, both existing AWS and non-AWS environments'
    },
    {
        id:3,
        cont: 'Advisory and AWS consulting services helping your business through end user adoption cycles'
    },
    {
        id:4,
        cont: 'Integration services either application to application, B2B, IoT and SaaS'
    },
    {
        id:5,
        cont: 'Security service with insights and visibility to monitor and respond promptly'
    },
    {
        id:6,
        cont: 'Customized design of your AWS cloud'
    }
]