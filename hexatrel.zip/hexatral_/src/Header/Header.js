import React, {useState} from 'react'
import {Link} from 'react-router-dom'
import './Header.css'
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import MenuRoundedIcon from '@mui/icons-material/MenuRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import cloudMan from '../assets/11-man-cloud.jpg'
import cloudNew from '../assets/cloud-new.jpg'
import about from '../assets/about.jpg'

const Header = () => {
    const [nav, setNav] = useState(false);
    const showSideBar = () => setNav(!nav);
    const[active, setActive] = useState(false);
    const activeClass = () => setActive(!active);
    return(
        <div className='Header'>
            <nav class="navbar">
                <Link to="/" class="nav-logo">Hexatral</Link>
                <div className={nav? 'sideBar active' : 'sideBar'} onClick={showSideBar}>
                </div> 
                <div class="hamburger" onClick={showSideBar}>
                   MENU{nav? <CloseRoundedIcon /> : <MenuRoundedIcon />}
                </div>
                
                <ul class={nav? "nav-menu active" : "nav-menu"}>
                    <li class="nav-item">
                        <Link to="#" class="nav-link">Services <ArrowDropDownIcon />
                            <div className='listHover'>
                                <div className='liHoverTitle'>
                                    <div onClick={activeClass} className={active? 'li-hov-title' : 'li-hov-title active'}> Infrastructure </div>
                                    <div onClick={activeClass} className={active? 'li-hov-title active' : 'li-hov-title'}> Cloud </div>
                                    <div className='li-hov-title'> Product Engg & Development </div>
                                </div>
                                <div className='liHoverCont'>
                                    <div className='li-hov-cont'><Link to='/aws'>Datacenter To Cloud Migrations</Link></div>
                                    <div className='li-hov-cont'>Datacenter Deployment & Management</div>
                                    <div className='li-hov-cont'>Enterprise Security</div>
                                    <div className='li-hov-cont'>IT Consulting</div>
                                </div>
                                <div className='liHoverImg'>
                                    <img src={cloudMan} alt='' />
                                </div>
                            </div>
                        </Link>
                    </li>
                    <li class="nav-item">
                        <Link to="#" class="nav-link">Cloud Transformation <ArrowDropDownIcon />
                            <div className='listHover'>
                                <div className='liHoverTitle'>
                                    <div onClick={activeClass} className={active? 'li-hov-title' : 'li-hov-title active'}> RPA </div>
                                    <div onClick={activeClass} className={active? 'li-hov-title active' : 'li-hov-title'}> Product Engg & Development </div>
                                    <div className='li-hov-title'> Artificial Intelligence</div>
                                    <div className='li-hov-title'> Enterprise Testitng</div>
                                    <div className='li-hov-title'> Contact Center</div>
                                </div>
                                <div className='liHoverCont'>
                                    <div className='li-hov-cont'><Link to='/aws'>UI Path</Link></div>
                                    <div className='li-hov-cont'>Automation Anywhere</div>
                                    <div className='li-hov-cont'>Work Fusion</div>
                                </div>
                                <div className='liHoverImg'>
                                    <img src={cloudNew} alt='' />
                                </div>
                            </div>
                        </Link>
                    </li>
                    <li class="nav-item">
                        <Link to="#" class="nav-link">Our Products <ArrowDropDownIcon />
                            <div className='listHover active1'>
                                <div className='liHoverCont'>
                                    <div onClick={activeClass} className={active? 'li-hov-cont active' : 'li-hov-cont'}> Digital Marketing Automation Software </div>
                                    <div onClick={activeClass} className={active? 'li-hov-cont active' : 'li-hov-cont'}> ERP Software </div>
                                    <div className='li-hov-cont'>Custom Software Development </div>
                                    <div className='li-hov-cont'>Cloud SaaS </div>
                                    <div className='li-hov-cont'>Ticketing Software </div>
                                    <div className='li-hov-cont'>Chatbot Tool </div>
                                    <div className='li-hov-cont'>HRMS Software </div>
                                </div>
                            </div>
                        </Link>
                    </li>
                    <li class="nav-item">
                        <Link to="#" class="nav-link">Corporate <ArrowDropDownIcon />
                            <div className='listHover active2'>
                                <div className='liHoverTitle'>
                                    <div onClick={activeClass} className={active? 'li-hov-title' : 'li-hov-title active'}> About </div>
                                    <div onClick={activeClass} className={active? 'li-hov-title active' : 'li-hov-title'}> Resource </div>
                                    <div className='li-hov-title'> Why Us </div>
                                </div>
                                <div className='liHoverCont'>
                                    <div className='li-hov-cont'><Link to='/aws'>Who We Are</Link></div>
                                    <div className='li-hov-cont'>Our Mission</div>
                                    <div className='li-hov-cont'>Partners</div>
                                </div>
                                <div className='liHoverImg'>
                                    <img src={about} alt='' />
                                </div>
                            </div>
                        </Link>
                    </li>
                    <li class="nav-item">
                        <Link to="#" class="nav-link">Careers</Link>
                    </li>
                    <li class="nav-item">
                        <Link to="/contact-us" class="nav-link">Contact</Link>
                    </li>
                </ul>               
            </nav>                           
        </div>    
    )
}

export default Header
