import React from 'react'
import Hero from '../Hero/Hero';
import Container from '../Container/Container'
import Caroussel from '../Caroussel/Caroussel'
import Slider from '../Slider/Slider'

function Home() {
    return (
      <>
        <Slider />
        <Hero />
        <Container />
        <Caroussel />
      </>   
    );
  }
  
  export default Home;