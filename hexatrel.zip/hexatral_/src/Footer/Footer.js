import React from 'react'
import './Footer.css'
import { Facebook, LinkedIn, Mail, Twitter, YouTube } from '@mui/icons-material'
import { Call } from '@mui/icons-material'
import {Link} from 'react-router-dom'

const Footer = () => {
    return(
        <div className='Footer'>
            <div className='footerCont'>
                
                <div className='footerList'>
                    <h3>Application Services</h3>
                    <ul>
                        
                        <li><Link to='/header'>SharePoint </Link></li>                       
                        <li><Link to=''> Power Platform</Link></li>
                        <li><Link to=''>.Net Development</Link></li>
                        <li><Link to=''>Dynamic Ax </Link></li>
                        <li><Link to=''>Full Stack </Link></li>
                    </ul>
                </div>
                <div className='footerList'>
                    <h3>Cloud Services</h3>
                    <ul>
                        <li><Link to=''>AWS </Link></li>
                        <li><Link to=''>Azure </Link></li>
                        <li><Link to=''>Google Cloud</Link></li>
                        <li><Link to=''>Dynamic 365</Link></li>
                        <li><Link to=''>Office 365</Link></li>
                    </ul>
                </div>
                <div className='footerList'>
                    <h3>Industries</h3>
                    <ul>
                        <li><Link to=''>Healthcare/Hospitals</Link></li>
                        <li><Link to=''>Pharmaceuticals</Link></li>
                        <li><Link to=''>Manufacturing</Link></li>
                        <li><Link to=''>Insurance</Link></li>
                        <li><Link to=''>Biking & Finance</Link></li>
                    </ul>
                </div>
                <div className='footerList'>
                    <h3>Contact Us</h3>
                    <ul>
                        <li className='contact'><Link to=''><Mail style={style} /> info@hexatral.com</Link></li>
                        <li className='contact'><Link to=''><Call style={style}/> +91 8939 2222 18</Link></li>
                        <li></li>
                        <span>Connect With Us</span>
                        <li>
                            <Link to=''><Twitter style={style}/></Link> 
                            <Link to=''><Facebook style={style}/> </Link>
                            <Link to=''><LinkedIn style={style}/> </Link>
                            <Link to=''><YouTube style={style}/> </Link>
                        </li>
                    </ul>
                </div>
                
            </div>

            <div className='footerPolicy'>
                <div className='footerPrivacy'>
                        <div className='privacyBtn'><Link to='/hero'>Privacy Policy </Link></div>
                        <div className='capabilityBtn'><Link to='/hero'>Capability Statement </Link></div>
                        <div className='mapBtn'><Link to='/hero'>Sitemap </Link></div>
                </div>
                <div className='footerCopyright'>
                    Copyright © 2021 Hexatral LLC. All rights reserved.
                </div>
            </div>
        </div>
    )
}

export default Footer

const style = {
    marginRight: '8px'
}