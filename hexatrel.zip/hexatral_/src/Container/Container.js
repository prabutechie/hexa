import React from 'react'
import './Container.css'
import bankingIndustry from '../assets/banking-industry.png'
import healthcareIndustry from '../assets/healthcare-industry.png'
import insuranceIndustry from '../assets/insurance-industry.png'
import manufacturingIndustry from '../assets/manufacturing-industry.png'
import pharmaIndustry from '../assets/pharma-industry.png'

const Container = () =>{
    return(
        <div className='Container'>
            <div className='indusCont'>
                <div className='industryLeft'>
                    <span>Industries</span> <br /> <h2>We Serve</h2>
                    <p>Our digital transformation experts provide business values that help our clients identify and realize goals, 
                        optimize & enhance operational efficiencies.
                    </p>
                </div>
                <div className='indusRight'>
                    <div className='indusRightFirst'>
                        <img src={bankingIndustry} alt='' />
                        <img src={healthcareIndustry} alt='' />
                        <img src={insuranceIndustry} alt='' />
                    </div>
                    <div className='indusRightSecond'>
                        <img src={manufacturingIndustry} alt='' />
                        <img src={pharmaIndustry} alt='' />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Container