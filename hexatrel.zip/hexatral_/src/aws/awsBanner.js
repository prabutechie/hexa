import React from 'react'
import './aws.css'

const AwsBanner=()=>{    
    return(
        <div className='awsBanner'>
            <h1>Fully Managed AWS Services</h1>          
        </div>
    )
}

export default AwsBanner