import React from 'react'
import './aws.css'

const AwsFooter=()=>{
    return(
        <div className='awsFooter'>
            <h2>HexaCorp is with you every step of the way</h2>
        </div>
    )
}

export default AwsFooter