import React from 'react'
import './aws.css'
import audit from '../assets/awsImg/audit.png'
import cost from '../assets/awsImg/cost.png'
import thread from '../assets/awsImg/threat.png'
import integration from '../assets/awsImg/integration.png'
import signature from '../assets/awsImg/signature.png'
import tv from '../assets/awsImg/tv.png'


const AwsHero=()=>{
    return(
        <div className='awsHero'>
            <div className='awsManaged'>
                <h2>Managed AWS</h2>
                <p>Peace of mind on cloud nine. Pun intended. HexaCorp is your full-scale managed AWS consulting partner. We are a trusted managed IT services provider (MSP) across several industries. 
                    Our skilled amazon web services experts will help you drive your strategic AWS adoption across a wide spectrum of public, private and hybrid environments.
                </p>
            </div>
            <div className='managedService'>
                <div className='ManagedServiceHeader'>
                    <h2>Our AWS managed services</h2>
                </div>
                <div className='managedServiceList'>
                   {managedTxt.map((mgmnt, index)=>(
                    <div className='managedList' key={index}>
                        <div className='mgmntImg'>
                            <img src={mgmnt.url} alt='' />
                        </div>
                        <div className='mgmntCont'>
                            <h3>{mgmnt.head}</h3>
                            <p>{mgmnt.paragraph}</p>
                        </div>
                    </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default AwsHero

const managedTxt = [
    {
        id: 1,
        url: thread,
        head: 'Monitor vulnerabilities and threats with state-of-the-art backup',
        paragraph:'We ensure you have the best disaster recovery solutions, monitoring and failover management'
    },
    {
        id: 2,
        url: tv,
        head: 'Continuous monitoring',
        paragraph:'Proactive management of your cloud environment'
    },
    {
        id: 3,
        url: cost,
        head: 'Budget control',
        paragraph:'Track your budget and optimize your cloud service'
    },
    {
        id: 4,
        url: integration,
        head: 'Continuous integration and development',
        paragraph:'Get going with continuous solution delivery using Docker, Kubernetes and other leading technologies'
    },
    {
        id: 5,
        url: signature,
        head: 'KPI reporting',
        paragraph:'Manage and scrutinize your workload performance more effectively'
    },
    {
        id: 6,
        url: audit,
        head: 'Compliance audit assistance',
        paragraph:'End to end service with compliance audits'
    }
]