import React from 'react'
import './aws.css'
import AwsBanner from './awsBanner'
import AwsContainer from './awsContainer'
import AwsFooter from './awsFooter'
import AwsHero from './awsHero'

function Aws(){
    return(
        <>
            <AwsBanner />
            <AwsHero />
            <AwsContainer />
            <AwsFooter />     
        </>
    )
}

export default Aws