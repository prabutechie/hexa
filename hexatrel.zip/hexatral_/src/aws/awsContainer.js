import React from 'react'
import './aws.css'
import backup from '../assets/awsImg/backup.png'
import chat from '../assets/awsImg/chat.png'
import pay from '../assets/awsImg/pay.png'
import speed from '../assets/awsImg/speed.png'
import truck from '../assets/awsImg/truck-1.png'
import caller from '../assets/awsImg/caller.png'
import thread1 from '../assets/awsImg/threat-1.png'


const AwsContainer=()=>{
    return(
        <div className='awsContainer'>
            <div className='hexacorpWhy'>
                <div className='managed-h2'>
                    <h2>Why Hexacorp?</h2>
                </div>
                <div className='hexacorpWhyList'>
                   {managedTxt.map((mgmnt, index)=>(
                    <div className='hexacorpList' key={index}>
                        <div className='mgmntImg'>
                            <img src={mgmnt.url} alt='' />
                        </div>
                        <div className='mgmntCont'>
                            <h3>{mgmnt.head}</h3>
                            <p>{mgmnt.paragraph}</p>
                        </div>
                    </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default AwsContainer

const managedTxt = [
    {
        id: 1,
        url: pay,
        head: 'Monitor vulnerabilities and threats with state-of-the-art backup',
        paragraph:'We ensure you have the best disaster recovery solutions, monitoring and failover management'
    },
    {
        id: 2,
        url: chat,
        head: 'Continuous monitoring',
        paragraph:'Proactive management of your cloud environment'
    },
    {
        id: 3,
        url: speed,
        head: 'Budget control',
        paragraph:'Track your budget and optimize your cloud service'
    },
    {
        id: 4,
        url: backup,
        head: 'Continuous integration and development',
        paragraph:'Get going with continuous solution delivery using Docker, Kubernetes and other leading technologies'
    },
    {
        id: 5,
        url: caller,
        head: 'KPI reporting',
        paragraph:'Manage and scrutinize your workload performance more effectively'
    },
    {
        id: 6,
        url: truck,
        head: 'Compliance audit assistance',
        paragraph:'End to end service with compliance audits'
    },
    {
        id: 7,
        url: thread1,
        head: 'Monitor vulnerabilities, anomalies and security threats',
        paragraph:'Proactively flag issues before they become critical!'
    }
]